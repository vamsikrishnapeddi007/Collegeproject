/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.sis.forms;



/**
 *
 * @author PEDDI'S
 */
public class StudentDataEntryForm extends org.apache.struts.action.ActionForm {
    private String er;
 private String idp;

    public String getIdp() {
        return idp;
    }

    public void setIdp(String idp) {
        this.idp = idp;
    }
    public String getEr() {
        return er;
    }

    public void setEr(String er) {
        this.er = er;
    }
    private String sid;
    private String sname;
    private String section;

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    private String acn;

    public String getAcn() {
        return acn;
    }

    public void setAcn(String acn) {
        this.acn = acn;
    }

    private String acd;
    private String awt;

    public String getAcd() {
        return acd;
    }

    public void setAcd(String acd) {
        this.acd = acd;
    }

    public String getAwt() {
        return awt;
    }

    public void setAwt(String awt) {
        this.awt = awt;
    }

    public String getAli() {
        return ali;
    }

    public void setAli(String ali) {
        this.ali = ali;
    }

    public String getAcg() {
        return acg;
    }

    public void setAcg(String acg) {
        this.acg = acg;
    }

    public String getApe() {
        return ape;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public String getMcd() {
        return mcd;
    }

    public void setMcd(String mcd) {
        this.mcd = mcd;
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn;
    }

    public String getMwt() {
        return mwt;
    }

    public void setMwt(String mwt) {
        this.mwt = mwt;
    }

    public String getMli() {
        return mli;
    }

    public void setMli(String mli) {
        this.mli = mli;
    }

    public String getMcg() {
        return mcg;
    }

    public void setMcg(String mcg) {
        this.mcg = mcg;
    }

    public String getMpe() {
        return mpe;
    }

    public void setMpe(String mpe) {
        this.mpe = mpe;
    }
    private String ali;
    private String acg;
    private String ape;
    private String mcd;
    private String mcn;
    private String mwt;
    private String mli;
    private String mcg;
    private String mpe;
    private String scd;
    private String scn;
    private String swt;
    private String sli;

    public String getScd() {
        return scd;
    }

    public void setScd(String scd) {
        this.scd = scd;
    }

    public String getScn() {
        return scn;
    }

    public void setScn(String scn) {
        this.scn = scn;
    }

    public String getSwt() {
        return swt;
    }

    public void setSwt(String swt) {
        this.swt = swt;
    }

    public String getSli() {
        return sli;
    }

    public void setSli(String sli) {
        this.sli = sli;
    }

    public String getScg() {
        return scg;
    }

    public void setScg(String scg) {
        this.scg = scg;
    }

    public String getSpe() {
        return spe;
    }

    public void setSpe(String spe) {
        this.spe = spe;
    }
    private String scg;
    private String spe;

    
   
}
